import requests, feedparser, smtplib, ssl, time, os
from datetime import datetime, timedelta
from email.mime.text import MIMEText
from email.header import Header

# CONFIG - update these
EMAIL_SENDER = ""
EMAIL_PASSWORD = ""  # Use App Password from Google
EMAIL_RECEIVER = ["", ""] # Can Add more than on Email, or only one
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 465

# Keywords to detect breaches (secondary check)
KEYWORDS = [
    "breach", "cybersecurity incident", "data leak", "data exposure", "unauthorized access",
    "ransomware", "security incident", "data compromise", "information security", "cyber attack", "hack"
]

POLL_INTERVAL = 1800  # seconds between checks (30 minutes)
HEARTBEAT_DAYS = 1    # days between heartbeat emails

WORK_DIR = os.path.dirname(os.path.abspath(__file__))
SEEN_FILE = os.path.join(WORK_DIR, "seen_ids.txt")
LOG_FILE = os.path.join(WORK_DIR, "breachbot.log")

# Track last heartbeat
last_heartbeat = datetime.now() - timedelta(days=HEARTBEAT_DAYS)

# Track scan counts
sec_count = 0

def log(msg):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"{ts} - {msg}\n"
    print(line, end="")
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line)
    except Exception as e:
        print(f"Failed to write log: {e}")

def load_seen_ids():
    if not os.path.exists(SEEN_FILE):
        return set()
    try:
        with open(SEEN_FILE, "r", encoding="utf-8") as f:
            return set(line.strip() for line in f if line.strip())
    except Exception as e:
        log(f"Error loading seen ids: {e}")
        return set()

def save_seen_id(entry_id):
    try:
        with open(SEEN_FILE, "a", encoding="utf-8") as f:
            f.write(entry_id + "\n")
    except Exception as e:
        log(f"Error saving seen id: {e}")

def send_email(subject, body):
    msg = MIMEText(body, "plain", "utf-8")
    msg["Subject"] = Header(subject, "utf-8")
    msg["From"] = EMAIL_SENDER
    msg["To"] = ", ".join(EMAIL_RECEIVER)  # show all in To field

    context = ssl.create_default_context()
    with smtplib.SMTP_SSL(SMTP_SERVER, SMTP_PORT, context=context) as server:
        server.login(EMAIL_SENDER, EMAIL_PASSWORD)
        server.sendmail(EMAIL_SENDER, EMAIL_RECEIVER, msg.as_string())
    log(f"Email sent: {subject}")

def looks_like_breach(text):
    if not text:
        return False
    # Primary check: SEC's required disclosure item
    if "item 1.05" in text.lower():
        return True
    # Secondary: keyword scan
    t = text.lower()
    for k in KEYWORDS:
        if k in t:
            return True
    return False

def check_sec_filings(seen_ids):
    global sec_count
    url = "https://www.sec.gov/cgi-bin/browse-edgar?action=getcurrent&type=8-K&output=atom"
    try:
        feed = feedparser.parse(url)
    except Exception as e:
        log(f"Failed to fetch SEC feed: {e}")
        return seen_ids
    for entry in feed.entries:
        sec_count += 1
        entry_id = getattr(entry, "id", "") or (entry.get("link","") + "|" + entry.get("title",""))
        if entry_id in seen_ids:
            continue
        title = entry.get("title","") or ""
        summary = entry.get("summary","") or entry.get("content","")
        combined = f"{title}\n{summary}"
        if looks_like_breach(combined):
            subject = "🚨 SEC Breach Filing Detected"
            body = f"Title: {title}\nLink: {entry.get('link','')}\n\nSummary:\n{summary}"
            try:
                send_email(subject, body)
            except Exception as e:
                log(f"Failed to send SEC email: {e}")
            log(f"Detected SEC breach filing: {title}")
        save_seen_id(entry_id)
        seen_ids.add(entry_id)
    return seen_ids

def send_heartbeat():
    global last_heartbeat, sec_count
    now = datetime.now()
    if now - last_heartbeat >= timedelta(days=HEARTBEAT_DAYS):
        subject = "💓 BreachBot Daily Heartbeat"
        body = (
            f"BreachBot is running fine.\n\nTime: {now.strftime('%Y-%m-%d %H:%M:%S')}\n\n"
            f"SEC filings scanned in last 24h: {sec_count}"
        )
        try:
            send_email(subject, body)
            last_heartbeat = now
            sec_count = 0
        except Exception as e:
            log(f"Failed to send heartbeat: {e}")

def main_loop():
    seen_ids = load_seen_ids()
    log(f"Starting BreachBot. Seen IDs loaded: {len(seen_ids)}")
    while True:
        try:
            seen_ids = check_sec_filings(seen_ids)
            send_heartbeat()
        except Exception as e:
            log(f"Unexpected error in loop: {e}")
        time.sleep(POLL_INTERVAL)

if __name__ == "__main__":
    main_loop()
